# DHV E-STUDENT — Sàn giao dịch sinh viên

Website thuần **HTML/CSS/JavaScript** (không React, không cần Node/npm/build gì cả) — đúng với công nghệ đã ghi trong báo cáo NCKH.

## Cách chạy
- **Nhanh nhất:** mở thẳng file `index.html` bằng trình duyệt (double-click) — chạy được ngay, không cần internet (trừ font chữ Google Fonts, nếu mất mạng web vẫn chạy bình thường, chỉ là font sẽ về font hệ thống).
- **Đúng môi trường XAMPP:** copy cả thư mục `dhv-e-student` vào `C:\xampp\htdocs\`, bật Apache trong XAMPP Control Panel, rồi mở `http://localhost/dhv-e-student/` trên trình duyệt.

## Cấu trúc thư mục
```
dhv-e-student/
├── index.html          → khung trang + toàn bộ nội dung HTML
├── css/
│   └── style.css        → toàn bộ giao diện/màu sắc/layout
└── js/
    ├── data.js           → dữ liệu mẫu (danh mục, sản phẩm, gia sư, diễn đàn, việc làm)
    ├── state.js           → trạng thái hiện tại (trang, giỏ hàng, bộ lọc...)
    ├── utils.js           → hàm tiện ích (định dạng giá, sao đánh giá, toast)
    ├── cards.js           → vẽ từng thẻ sản phẩm/gia sư/bài viết/việc làm
    ├── wishlist.js        → yêu thích sản phẩm
    ├── cart.js             → giỏ hàng
    ├── search.js           → tìm kiếm tổng (ô tìm kiếm trên header)
    ├── modals.js           → popup chi tiết sản phẩm/gia sư
    ├── nav.js               → điều hướng giữa các trang
    ├── pages/
    │   ├── home.js, products.js, tutors.js, forum.js, jobs.js  → mỗi trang 1 file
    └── app.js                → khởi động trang (nạp sau cùng)
```
Muốn sửa gì thì vào đúng file đó — ví dụ sửa dữ liệu sản phẩm thì vào `js/data.js`, đổi màu thì vào `css/style.css`, không cần lục cả file dài.

## Các lỗi đã sửa
1. **Tìm kiếm bị "mất" kết quả**: khi đang xem 1 danh mục (VD: Handmade) rồi dùng ô tìm kiếm trên header, danh mục cũ vẫn còn dính lại nên trang kết quả có thể hiện ít hơn hoặc 0 kết quả dù ô tìm kiếm báo có. Đã sửa để luôn về đúng danh mục "Tất cả" khi xem tất cả kết quả.
2. Nhấn **Enter** trong ô tìm kiếm giờ nhảy thẳng tới trang kết quả đầy đủ (trước đây không có tác dụng).
3. Nút "Xem tất cả →" ở mục **Đồ secondhand hot nhất** (trang chủ) trước đây luôn hiện tất cả sản phẩm thay vì chỉ đồ secondhand — đã sửa đúng theo ý đồ.
4. Thanh menu trên cùng trước đây sáng đèn **cùng lúc cả 4 mục** (Mua & Bán / Thời trang / Điện tử / Handmade) bất kể đang chọn mục nào — giờ chỉ sáng đúng 1 mục đang xem.
5. Các nút 🔔 / 👤 / Đăng nhập / Đăng ký trước đây bấm vô không có phản hồi gì — đã thêm thông báo nhỏ (toast) cho đồng bộ với các nút khác trong web.

## Lưu ý
Dữ liệu (sản phẩm, gia sư, đơn hàng...) hiện đang là dữ liệu mẫu nằm trong `js/data.js`, chưa kết nối CSDL MySQL thật qua PHP. Khi nào cần lưu dữ liệu thật, chỉ cần viết các file `.php` gọi MySQL rồi thay nội dung `js/data.js` bằng `fetch()` gọi tới các file PHP đó — phần giao diện ở các file khác không cần sửa.
