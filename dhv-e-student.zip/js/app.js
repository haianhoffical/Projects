// ============================================================================
// app.js — Điểm khởi động của web. File này phải được tải SAU CÙNG (xem thứ
// tự script trong index.html) vì nó gọi renderHome() ngay khi chạy, lúc đó
// mọi dữ liệu (data.js) và hàm vẽ trang (pages/home.js, cards.js...) cần đã
// được nạp xong từ trước.
// ============================================================================
renderHome();
