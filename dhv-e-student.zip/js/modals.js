// ============================================================================
// modals.js — Cửa sổ chi tiết hiện lên (popup) khi xem 1 sản phẩm hoặc 1 gia
// sư cụ thể.
// ============================================================================
function openProductModal(id){
  const p=PRODUCTS.find(x=>x.id===id); if(!p) return;
  document.getElementById('modal-box').innerHTML=`
    <div class="mh"><div><span class="cnd ${p.cond==='new'?'new':p.cond==='used'?'used':'sh2'}">${p.cond==='new'?'Mới':p.cond==='used'?'Đã dùng':'Second-hand'}</span></div><button class="mcl" onclick="closeModal()">✕</button></div>
    <div class="mbody">
      <div class="m-pimg ${p.bg}">${p.e}</div>
      <div class="m-pname">${p.n}</div>
      <div class="m-price">${priceStr(p.p)}</div>
      ${p.op?`<div class="m-oprice">Giá gốc: ${priceStr(p.op)} – Tiết kiệm ${priceStr(p.op-p.p)}</div>`:''}
      <div class="m-seller">👤 Người bán: <strong>${p.seller}</strong> &nbsp;|&nbsp; 📍 ${p.loc} &nbsp;|&nbsp; ⭐ Đã xác thực DHV</div>
      <div class="m-desc">${p.desc}</div>
      <div class="m-btns">
        <button class="m-add" onclick="addToCart(${p.id});showToast('Đã thêm vào giỏ!')">🛒 Thêm vào giỏ</button>
        <button class="m-chat" onclick="showToast('Đã gửi tin nhắn đến ${p.seller}! 💬')">💬 Nhắn tin người bán</button>
      </div>
    </div>`;
  document.getElementById('modal').classList.remove('hide');
}
function openTutorModal(id){
  const t=TUTORS.find(x=>x.id===id); if(!t) return;
  document.getElementById('modal-box').innerHTML=`
    <div class="mh"><div></div><button class="mcl" onclick="closeModal()">✕</button></div>
    <div class="mbody">
      <div class="m-tav" style="background:linear-gradient(135deg,${t.color},${t.color}99)">${t.init}</div>
      <div class="m-tname">${t.name}</div>
      <div class="m-tinfo">${t.faculty} · ${t.year} &nbsp;|&nbsp; 📍 ${t.area}</div>
      <div class="m-tsubj">${t.subjects.map(s=>`<span class="m-stag">${s}</span>`).join('')}</div>
      <div class="m-tprice">${priceStr(t.price)}</div>
      <div class="m-tsub">mỗi giờ · Lịch dạy: ${t.avail}</div>
      <div class="m-trat"><span class="m-stars">${stars(t.rating)}</span><span style="font-size:16px;font-weight:700">${t.rating}/5.0</span><span style="color:var(--muted)">(${t.reviews} đánh giá)</span></div>
      <div class="m-tbio">📝 ${t.bio}</div>
      <button class="contact-full" onclick="showToast('Đã gửi yêu cầu kết nối đến ${t.name}! 🎉');closeModal()">📩 Gửi yêu cầu kết nối ngay</button>
    </div>`;
  document.getElementById('modal').classList.remove('hide');
}
function closeModal(e){ if(!e||e.target===e.currentTarget||e.currentTarget.tagName==='BUTTON') document.getElementById('modal').classList.add('hide'); }
