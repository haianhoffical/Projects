// ============================================================================
// cart.js — Giỏ hàng: thêm sản phẩm, đổi số lượng, xoá, hiện tổng tiền.
// ============================================================================
function addToCart(id){
  const p = PRODUCTS.find(x=>x.id===id); if(!p) return;
  const ex = S.cart.find(x=>x.id===id);
  if(ex) ex.qty++; else S.cart.push({...p, qty:1});
  updateCartBadge(); showToast(`Đã thêm "${p.n.substring(0,25)}..." vào giỏ 🛒`);
}
function updateCartBadge(){ document.getElementById('cart-badge').textContent=S.cart.reduce((a,b)=>a+b.qty,0); }
function toggleCart(){
  const ov=document.getElementById('cart-overlay'), sb=document.getElementById('cart-sidebar');
  const isOpen=sb.classList.contains('open');
  ov.classList.toggle('hide',isOpen); sb.classList.toggle('open',!isOpen);
  if(!isOpen) renderCart();
}
function renderCart(){
  const body=document.getElementById('cart-body'), ftr=document.getElementById('cart-footer');
  if(!S.cart.length){ body.innerHTML=`<div class="ecrt"><div class="ecico">🛒</div><p>Giỏ hàng trống</p><button onclick="toggleCart();navigate('products',{pcat:'all'})">Mua sắm ngay</button></div>`; ftr.innerHTML=''; return; }
  body.innerHTML=S.cart.map(item=>`<div class="ci">
    <div class="ciimg">${item.e}</div>
    <div class="cii">
      <div class="cin">${item.n.substring(0,40)}${item.n.length>40?'...':''}</div>
      <div class="cip">${priceStr(item.p)}</div>
      <div class="ciqw">
        <button class="qb" onclick="updateQty(${item.id},-1)">−</button>
        <span class="qn">${item.qty}</span>
        <button class="qb" onclick="updateQty(${item.id},1)">+</button>
      </div>
    </div>
    <button class="cdel" onclick="removeCartItem(${item.id})">🗑️</button>
  </div>`).join('');
  const total=S.cart.reduce((a,b)=>a+b.p*b.qty,0);
  ftr.innerHTML=`<div class="ctot"><span>Tổng cộng:</span><span style="color:var(--red)">${priceStr(total)}</span></div><button class="ckbtn" onclick="showToast('Tính năng thanh toán sẽ sớm ra mắt! 🎉')">Thanh toán ngay 💳</button>`;
}
function updateQty(id, delta){
  const item=S.cart.find(x=>x.id===id); if(!item) return;
  item.qty+=delta; if(item.qty<=0) S.cart=S.cart.filter(x=>x.id!==id);
  updateCartBadge(); renderCart();
}
function removeCartItem(id){ S.cart=S.cart.filter(x=>x.id!==id); updateCartBadge(); renderCart(); }
