// ============================================================================
// utils.js — Các hàm tiện ích nhỏ, dùng lại ở nhiều nơi: định dạng giá tiền,
// vẽ sao đánh giá, in nhãn tình trạng sản phẩm, và hiển thị thông báo nổi
// (toast) ở cuối màn hình.
// ============================================================================

function condLabel(c){ return c==='new'?'<span class="cnd new">Mới</span>':c==='used'?'<span class="cnd used">Đã dùng</span>':'<span class="cnd sh2">Second-hand</span>'; }
function priceStr(p){ return p.toLocaleString('vi-VN')+'đ'; }
function stars(r){ const full=Math.floor(r),half=r-full>=0.5; let s=''; for(let i=0;i<5;i++) s+=i<full?'★':(i===full&&half?'½':'☆'); return s; }

// ── TOAST: thông báo nổi nhỏ ở dưới màn hình ────────────────────────────────
let toastTimer;
function showToast(msg){ const t=document.getElementById('toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove('show'),3000); }
