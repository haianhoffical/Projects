// ============================================================================
// cards.js — Các hàm tạo HTML cho từng "thẻ" (card) hiển thị: thẻ sản phẩm,
// thẻ gia sư, thẻ bài diễn đàn, thẻ việc làm. Mỗi hàm nhận 1 object dữ liệu
// và trả về đoạn HTML tương ứng để chèn vào trang.
// ============================================================================

function productCard(p, showAdd=true){
  const liked = S.wishlist.has(p.id);
  return `<div class="pcard" onclick="openProductModal(${p.id})">
    <div class="pimg ${p.bg}">${p.e}${condLabel(p.cond)}<button class="wl${liked?' liked':''}" data-id="${p.id}" onclick="event.stopPropagation();toggleWishlist(${p.id},this)">♥</button></div>
    <div class="pinf">
      <div class="pn">${p.n}</div>
      <div class="pp">${priceStr(p.p)}${p.op?` <s>${priceStr(p.op)}</s>`:''}</div>
      <div class="pm"><span>👤 ${p.seller}</span><span>📍 ${p.loc}</span></div>
    </div>
    ${showAdd?`<button class="padd" onclick="event.stopPropagation();addToCart(${p.id})">🛒 Thêm vào giỏ</button>`:''}
  </div>`;
}

function tutorCard(t){
  return `<div class="tcard" onclick="openTutorModal(${t.id})">
    <div class="tav" style="background:linear-gradient(135deg,${t.color},${t.color}99)">${t.init}</div>
    <div class="tn2">${t.name}</div>
    <div class="ts2">${t.faculty} · ${t.year}</div>
    <div class="tsubj">${t.subjects.slice(0,3).map(s=>`<span class="tsj">${s}</span>`).join('')}${t.subjects.length>3?`<span class="tsj">+${t.subjects.length-3}</span>`:''}</div>
    <div class="trat"><span class="stars" style="color:#F59E0B">${stars(t.rating)}</span><span class="rn">${t.rating} (${t.reviews})</span></div>
    <div class="tprc">${priceStr(t.price)}<span>/giờ</span></div>
    <div class="tchp">📍 ${t.area}</div>
    <button class="cbtn2" onclick="event.stopPropagation();showToast('Đã gửi yêu cầu kết nối đến ${t.name}! 🎉')">📩 Liên hệ ngay</button>
  </div>`;
}

function forumCard(f){
  const cats={'Học tập':'','Chia sẻ':'chia','Hỏi đáp':'hoi'};
  const hotTag = f.hot?'<span style="background:#FFE4E6;color:#DC2626;padding:2px 8px;border-radius:20px;font-size:10px;font-weight:800;margin-left:6px">🔥 Hot</span>':'';
  return `<div class="fcard" onclick="showToast('Tính năng xem bài viết sẽ sớm ra mắt!')">
    <div class="fh">
      <div class="fav3" style="background:linear-gradient(135deg,${f.color},${f.color}aa)">${f.init}</div>
      <div style="flex:1"><div class="fu">${f.author} · ${f.faculty}</div><div class="ft3">${f.time}</div></div>
      <span class="fcat ${cats[f.cat]||''}">${f.cat}</span>${hotTag}
    </div>
    <div class="ftit">${f.title}</div>
    <div class="fprev">${f.prev}</div>
    <div class="fst3"><span>👁️ ${f.views} xem</span><span>💬 ${f.cmts} bình luận</span><span>❤️ ${f.likes} thích</span></div>
  </div>`;
}

function jobCard(j){
  return `<div class="jcard">
    <div class="jlg">${j.logo}</div>
    <div class="ji">
      <div class="jt">${j.title}${j.urgent?'<span style="background:#FEF3C7;color:#D97706;font-size:10px;font-weight:800;padding:2px 8px;border-radius:20px;margin-left:8px">⚡ Gấp</span>':''}</div>
      <div class="jc">${j.co}</div>
      <div class="jtags">
        <span class="jt2 tp">${j.type}</span>
        <span class="jt2 ty">💰 ${j.pay}</span>
        <span class="jt2 tg">📍 ${j.loc}</span>
      </div>
    </div>
    <button class="apbtn" onclick="showToast('Đã lưu tin tuyển dụng! 💼')">Ứng tuyển</button>
  </div>`;
}
