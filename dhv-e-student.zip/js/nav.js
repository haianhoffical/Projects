// ============================================================================
// nav.js — Bộ điều hướng trung tâm: chuyển trang, highlight đúng mục đang
// chọn trên thanh menu, và reset bộ lọc khi cần.
//
// ĐÃ SỬA so với bản gốc:
//  1) navigate() giờ áp dụng đúng tham số pcond/psearch khi được truyền vào
//     (trước đây chỉ áp dụng pcat, nên nút "Xem tất cả" của mục đồ secondhand
//     ở trang chủ luôn bị reset về "Tất cả" thay vì chỉ lọc đồ secondhand).
//  2) Thanh menu trên cùng giờ chỉ sáng đúng 1 mục đang chọn. Trước đây 4 mục
//     "Mua & Bán/Thời trang/Điện tử/Handmade" luôn sáng cùng lúc vì chúng dùng
//     chung data-page="products", không phân biệt danh mục con.
// ============================================================================

function navigate(page, params={}) {
  S.page = page;
  if(params.pcat !== undefined){
    S.pcat = params.pcat;
    S.pcond = params.pcond !== undefined ? params.pcond : 'all';
    S.psort = 'newest';
    S.psearch = params.psearch !== undefined ? params.psearch : '';
    document.getElementById('pcond').value = S.pcond;
    document.getElementById('psort').value = 'newest';
    document.getElementById('psearch').value = S.psearch;
  }
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.getElementById('page-'+page)?.classList.add('active');
  document.querySelectorAll('.ni').forEach(n=>n.classList.remove('act'));
  document.querySelectorAll(`.ni[data-page="${page}"]`).forEach(n=>{
    if(page==='products' && n.dataset.pcat){ if(n.dataset.pcat===S.pcat) n.classList.add('act'); }
    else n.classList.add('act');
  });
  closeSearch();
  if(page==='home') renderHome();
  if(page==='products') renderProducts();
  if(page==='tutors') renderTutors();
  if(page==='forum') renderForum();
  if(page==='jobs') renderJobs();
  window.scrollTo({top:0,behavior:'smooth'});
}
