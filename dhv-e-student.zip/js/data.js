// ============================================================================
// data.js — Toàn bộ dữ liệu mẫu (danh mục, sản phẩm, gia sư, diễn đàn, việc làm)
// Đây là nơi DUY NHẤT cần sửa khi muốn thêm/sửa/xoá dữ liệu hiển thị trên web.
// Sau này nếu chuyển sang lấy dữ liệu thật từ MySQL qua PHP, chỉ cần thay nội
// dung các mảng dưới đây bằng kết quả gọi API PHP (fetch), các file khác
// (render giao diện, tìm kiếm, giỏ hàng...) không cần sửa gì thêm.
// ============================================================================

const CATS = [
  {id:'fashion',  e:'👗', n:'Thời trang', c:'342 tin', bg:'c1'},
  {id:'electronics',e:'📱',n:'Điện tử',   c:'215 tin', bg:'c2'},
  {id:'handmade', e:'🎨', n:'Handmade',   c:'128 tin', bg:'c3'},
  {id:'books',    e:'📚', n:'Sách vở',    c:'89 tin',  bg:'c4'},
  {id:'household',e:'🏠', n:'Gia dụng',   c:'156 tin', bg:'c5'},
  {id:'vehicles', e:'🚲', n:'Xe & PT',    c:'67 tin',  bg:'c6'},
  {id:'entertainment',e:'🎮',n:'Giải trí',c:'94 tin',  bg:'c7'},
  {id:'cosmetics',e:'💄', n:'Mỹ phẩm',   c:'73 tin',  bg:'c8'},
];

const PRODUCTS = [
  {id:1, n:'Áo hoodie oversize vintage unisex form rộng', p:85000, op:150000, cat:'fashion', cond:'secondhand', e:'👕', bg:'p1', seller:'Hải Anh', loc:'Q.6', desc:'Áo hoodie form oversize size M-L phù hợp cả nam lẫn nữ. Chất nỉ dày, giữ ấm tốt. Đã giặt sạch, không phai màu.'},
  {id:2, n:'iPhone 11 64GB còn BH, full phụ kiện chính hãng', p:4500000, op:5200000, cat:'electronics', cond:'used', e:'📱', bg:'p2', seller:'Minh Tuấn', loc:'KTX', desc:'iPhone 11 màu đen, pin còn 88%, kèm sạc cáp zin, tai nghe, hộp đựng. Còn bảo hành đến tháng 3/2025.'},
  {id:3, n:'Tranh vẽ tay handmade tặng sinh nhật người thân', p:120000, op:null, cat:'handmade', cond:'new', e:'🎨', bg:'p3', seller:'Bảo Ngân', loc:'Q.6', desc:'Tranh màu nước vẽ tay theo yêu cầu. Chân dung hoặc phong cảnh. Kích thước A4. Giao trong 3-5 ngày.'},
  {id:4, n:'Giáo trình Cơ sở dữ liệu + Lập trình Web DHV', p:35000, op:80000, cat:'books', cond:'used', e:'📚', bg:'p4', seller:'Thu Hà', loc:'Trường', desc:'Bộ 2 cuốn giáo trình môn CSDL và Lập trình Web dùng tại DHV. Còn ghi chú đầy đủ, có highlight.'},
  {id:5, n:'Laptop Dell Inspiron Core i5 SSD 256GB pin 5h', p:7800000, op:10000000, cat:'electronics', cond:'used', e:'💻', bg:'p5', seller:'Quang Đức', loc:'Q.6', desc:'Dell Inspiron 15 3000, i5 gen 10, RAM 8GB, SSD 256GB. Win 11 bản quyền. Máy đẹp không trầy xước.'},
  {id:6, n:'Máy ép trái cây mini để bàn ký túc xá', p:180000, op:250000, cat:'household', cond:'new', e:'🧃', bg:'p6', seller:'Lan Anh', loc:'KTX', desc:'Máy ép chậm mini 200W, đầu USB, dễ vệ sinh. Phù hợp để bàn KTX. Còn nguyên hộp chưa dùng.'},
  {id:7, n:'Giày Converse Chuck Taylor size 39 còn mới 95%', p:320000, op:650000, cat:'fashion', cond:'secondhand', e:'👟', bg:'p1', seller:'Thanh Bình', loc:'Q.6', desc:'Converse Classic màu trắng size 39. Mang 3 lần, giặt sạch. Không có vết ố. Kèm hộp.'},
  {id:8, n:'Màn hình LCD 22 inch Samsung Full HD chân đế rời', p:1200000, op:1800000, cat:'electronics', cond:'used', e:'🖥️', bg:'p7', seller:'Văn Khoa', loc:'Bình Chánh', desc:'Samsung LS22R350. Full HD 1080p, 75Hz. Không pixel lỗi. Có HDMI + VGA. Chân đế tháo rời được.'},
  {id:9, n:'Nến thơm handmade hương hoa cỏ tự nhiên 200g', p:95000, op:null, cat:'handmade', cond:'new', e:'🕯️', bg:'p3', seller:'Mỹ Hoa', loc:'Q.6', desc:'Nến đậu nành tự nhiên, mùi lavender + lemon grass. Cháy 30-40 tiếng. Có thể đặt theo mùi yêu thích.'},
  {id:10, n:'Đàn guitar acoustic gỗ thông còn tốt, có bao', p:900000, op:1500000, cat:'entertainment', cond:'used', e:'🎸', bg:'p4', seller:'Hoàng Nam', loc:'Q.6', desc:'Guitar acoustic size 41, gỗ thông nguyên tấm. Dây mới thay. Kèm bao da và capo. Âm thanh tốt.'},
  {id:11, n:'Xe đạp thể thao 21 tốc độ màu đen rất đẹp', p:2200000, op:3500000, cat:'vehicles', cond:'used', e:'🚲', bg:'p6', seller:'Duy Phong', loc:'Q.6', desc:'Xe đạp MTB 26 inch, 21 tốc độ Shimano. Khung nhôm nhẹ. Phanh đĩa trước sau. Còn tốt, đi được ngay.'},
  {id:12, n:'Set mỹ phẩm dưỡng da Innisfree Green Tea', p:250000, op:400000, cat:'cosmetics', cond:'new', e:'💄', bg:'p8', seller:'Ngọc Mai', loc:'Q.6', desc:'Set 3 món: sữa rửa mặt + nước hoa hồng + kem dưỡng. Còn hạn dùng 2026. Mua về không hợp da.'},
  {id:13, n:'Áo dài trắng học sinh size M còn mới tinh', p:150000, op:300000, cat:'fashion', cond:'secondhand', e:'👘', bg:'p5', seller:'Phương Thảo', loc:'Q.6', desc:'Áo dài trắng vải lụa size M. Mặc 2 lần dịp lễ. Giặt khô, không nhăn. Có quần trắng đi kèm.'},
  {id:14, n:'Quạt tích điện mini để bàn sạc USB cổng Type-C', p:120000, op:180000, cat:'household', cond:'new', e:'🌀', bg:'p7', seller:'Gia Huy', loc:'KTX', desc:'Quạt Xiaomi mini 3 cấp gió. Sạc Type-C, pin dùng 8 tiếng. Nhỏ gọn để bàn học rất tiện.'},
  {id:15, n:'Sách Lập trình Python từ cơ bản đến nâng cao', p:45000, op:90000, cat:'books', cond:'used', e:'📖', bg:'p4', seller:'Minh Khoa', loc:'Trường', desc:'Sách "Python for Everybody" bản dịch tiếng Việt. Có bài tập thực hành. Còn ghi chú tay ở nhiều chỗ.'},
  {id:16, n:'Tai nghe Sony WH-1000XM4 chống ồn chủ động', p:3500000, op:5500000, cat:'electronics', cond:'used', e:'🎧', bg:'p2', seller:'Anh Tuấn', loc:'Q.6', desc:'Sony WH-1000XM4 màu đen. Pin còn 80%, chống ồn vẫn rất tốt. Kèm túi đựng + cáp sạc. Có thể test.'},
];

const TUTORS = [
  {id:1, name:'Nguyễn Hải Anh', init:'HA', subjects:['Lập trình Web','CSDL','Java','PHP'], price:80000, rating:4.9, reviews:23, faculty:'Khoa KTCN', year:'K22', color:'#3B82F6', avail:'Linh hoạt các tối', area:'Q.6, KTX DHV', bio:'Sinh viên năm 3 CNTT, GPA 3.6/4.0. Có 1 năm kinh nghiệm dạy thêm lập trình. Phong cách dạy thực hành, giải thích bằng ví dụ thực tế.'},
  {id:2, name:'Lê Minh Tuấn', init:'MT', subjects:['Toán cao cấp','Vật lý','Giải tích','Đại số'], price:70000, rating:4.8, reviews:15, faculty:'Khoa KHTN', year:'K21', color:'#10B981', avail:'T2-T6 chiều', area:'Q.6, Q.8, Online', bio:'Sinh viên năm 4 Toán-Tin. Chuyên ôn thi đại cương cho SV năm 1-2. Kiên nhẫn, giải thích từng bước rõ ràng.'},
  {id:3, name:'Trần Bảo Ngân', init:'BN', subjects:['Kế toán','Tài chính','Kinh tế vi mô','Excel'], price:65000, rating:4.7, reviews:31, faculty:'Khoa KT', year:'K21', color:'#F59E0B', avail:'Cuối tuần', area:'Q.6, Q.11, Online', bio:'SV năm 4 Kế toán. Đã dạy cho 30+ sinh viên. Có tài liệu đề cương đầy đủ các môn KT.'},
  {id:4, name:'Phạm Quang Đức', init:'QD', subjects:['Thiết kế đồ họa','UI/UX','Figma','Photoshop'], price:90000, rating:5.0, reviews:8, faculty:'Khoa KTCN', year:'K22', color:'#8B5CF6', avail:'Tối T4, T6, T7', area:'Online, Q.6', bio:'Freelance designer, có portfolio thực tế. Dạy từ zero đến biết làm project. Hỗ trợ sau giờ học.'},
  {id:5, name:'Nguyễn Văn Khoa', init:'VK', subjects:['C/C++','Cấu trúc dữ liệu','Giải thuật','Python'], price:75000, rating:4.6, reviews:19, faculty:'Khoa KTCN', year:'K21', color:'#EF4444', avail:'T3, T5, T7 tối', area:'KTX, Q.6', bio:'SV năm 4 CNTT, giỏi lập trình, từng tham gia ACM ICPC. Dạy thực hành coding nhiều.'},
  {id:6, name:'Phùng Lan Anh', init:'LA', subjects:['Tiếng Anh','TOEIC','Giao tiếp','IELTS cơ bản'], price:60000, rating:4.9, reviews:42, faculty:'Khoa NN', year:'K20', color:'#06B6D4', avail:'Linh hoạt, Online', area:'Online, Q.6, Q.5', bio:'TOEIC 850. Đã dạy cho 50+ học sinh. Rất kiên nhẫn. Có phương pháp học TOEIC tăng 200 điểm.'},
  {id:7, name:'Hoàng Duy Phong', init:'DP', subjects:['Marketing','Quản trị KD','Excel','PowerPoint'], price:55000, rating:4.5, reviews:12, faculty:'Khoa KT', year:'K22', color:'#84CC16', avail:'T7, CN, Online', area:'Q.6, Q.5', bio:'SV Marketing năm 3. Đang thực tập tại agency lớn. Dạy thực hành, nhiều case study thực tế.'},
  {id:8, name:'Mai Thị Ngọc', init:'TN', subjects:['Hóa học','Sinh học','Hóa hữu cơ','Hóa phân tích'], price:65000, rating:4.7, reviews:7, faculty:'Khoa SP', year:'K21', color:'#F97316', avail:'T2-T6 sáng, Online', area:'Q.6, Online', bio:'SV Sư phạm Hóa năm 4. Phong cách dạy dễ hiểu, sử dụng nhiều hình ảnh minh họa. Có tài liệu ôn thi tốt.'},
];

const TUTOR_SUBJECTS = ['Tất cả','Lập trình','Toán','Tiếng Anh','Kế toán','Thiết kế','Hóa học','Marketing'];

const FORUM = [
  {id:1, author:'Hải Anh', init:'HA', faculty:'K22CNTT', time:'2 giờ trước', cat:'Học tập', title:'Ôn thi cuối kỳ môn CSDL – Ai cùng học nhóm không?', prev:'Mình đang ôn thi môn Cơ sở dữ liệu, có ai muốn lập nhóm học chung không ạ? Mình có tài liệu đề cương đầy đủ do thầy cung cấp...', views:142, cmts:23, likes:45, color:'#3B82F6', hot:false},
  {id:2, author:'Minh Tuấn', init:'MT', faculty:'K21QT', time:'5 giờ trước', cat:'Chia sẻ', title:'Review KTX DHV – Giá cả, tiện nghi, kinh nghiệm 2 năm ở', prev:'Mình ở KTX DHV được 2 năm, chia sẻ cho các bạn năm nhất về phòng ốc, an ninh, điện nước và cách sắp xếp cuộc sống...', views:389, cmts:51, likes:112, color:'#10B981', hot:false},
  {id:3, author:'Bảo Ngân', init:'BN', faculty:'K23KT', time:'Hôm qua', cat:'Hỏi đáp', title:'Đăng ký học phần bị lỗi hệ thống – có giải pháp không?', prev:'Mình vào đăng ký học phần bị báo lỗi "Không đủ điều kiện", nhưng điểm và học phí đều ổn. Nhờ mọi người tư vấn...', views:201, cmts:34, likes:28, color:'#F59E0B', hot:false},
  {id:4, author:'Quang Đức', init:'QD', faculty:'K22TKDH', time:'Hôm qua', cat:'Chia sẻ', title:'Phòng trọ gần DHV giá rẻ – tổng hợp địa chỉ tin cậy Q.6', prev:'Mình tổng hợp danh sách phòng trọ giá từ 1.2–2 triệu/tháng gần trường, chủ nhà tốt, không giờ giấc...', views:567, cmts:89, likes:234, color:'#EF4444', hot:true},
  {id:5, author:'Lan Anh', init:'LA', faculty:'K23NN', time:'2 ngày trước', cat:'Học tập', title:'Tài liệu ôn thi TOEIC từ 500→700 điểm – chia sẻ miễn phí', prev:'Mình vừa thi TOEIC được 720 điểm, chia sẻ lại bộ tài liệu đã ôn trong 3 tháng với 2 buổi/tuần...', views:445, cmts:67, likes:189, color:'#06B6D4', hot:false},
  {id:6, author:'Duy Phong', init:'DP', faculty:'K22MKT', time:'3 ngày trước', cat:'Hỏi đáp', title:'Thực tập Marketing ở đâu nhận sinh viên năm 2?', prev:'Mình đang tìm chỗ thực tập Marketing, công ty nào nhận SV năm 2 không ạ? Khu vực Q.6 hoặc Online...', views:156, cmts:29, likes:41, color:'#84CC16', hot:false},
];
const FORUM_CATS = ['Tất cả','Học tập','Chia sẻ','Hỏi đáp'];

const JOBS = [
  {id:1, title:'Nhân viên pha chế / phục vụ cuối tuần', co:'The Coffee House – Nguyễn Văn Linh, Q.6', type:'Part-time', pay:'25.000đ/giờ', loc:'Gần trường', logo:'☕', urgent:true},
  {id:2, title:'Nhân viên bán hàng điện máy cuối tuần', co:'Thegioididong – Chợ Bình Tây, Q.6', type:'Cuối tuần', pay:'3.000.000đ/tháng', loc:'Q.6', logo:'🏪', urgent:false},
  {id:3, title:'Thực tập sinh IT – Lập trình Web/App', co:'FPT Software – TP. Thủ Đức', type:'Thực tập', pay:'3-5tr/tháng', loc:'Q. Thủ Đức', logo:'💻', urgent:true},
  {id:4, title:'Shipper giao hàng linh hoạt theo giờ', co:'Grab Vietnam – Toàn TP.HCM', type:'Tự do', pay:'Thu nhập linh hoạt', loc:'Toàn TP', logo:'📦', urgent:false},
  {id:5, title:'Nhân viên Marketing Online – làm remote', co:'Startup TechViet – Online', type:'Part-time', pay:'4.000.000đ/tháng', loc:'Online', logo:'📣', urgent:true},
  {id:6, title:'Nhân viên kho hàng Shopee Express', co:'Shopee Express – Bình Chánh', type:'Part-time', pay:'22.000đ/giờ', loc:'Bình Chánh', logo:'🚀', urgent:false},
  {id:7, title:'Gia sư dạy kèm tại nhà – nhiều môn', co:'Trung tâm gia sư DHV Network', type:'Part-time', pay:'60-100k/giờ', loc:'Q.6, Q.8, Online', logo:'📝', urgent:false},
  {id:8, title:'Nhân viên phục vụ nhà hàng Buffet', co:'King BBQ – Quận 6, TP.HCM', type:'Part-time', pay:'26.000đ/giờ', loc:'Q.6', logo:'🍖', urgent:true},
];
const JOB_TYPES = ['Tất cả','Part-time','Thực tập','Tự do','Cuối tuần'];
