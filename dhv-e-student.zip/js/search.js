// ============================================================================
// search.js — Ô tìm kiếm tổng (trên header): gợi ý kết quả ngay khi gõ (có
// chờ 200ms để không gọi liên tục từng phím), và chuyển sang trang kết quả
// đầy đủ khi bấm "Xem tất cả" hoặc nhấn Enter.
//
// ĐÃ SỬA so với bản gốc:
//  1) Nhấn Enter giờ sẽ nhảy thẳng tới trang kết quả đầy đủ (trước đây nhấn
//     Enter không có tác dụng gì khác so với việc gõ bình thường).
//  2) Khi bấm "Xem tất cả N kết quả", trang Mua & Bán giờ luôn hiện đúng cả
//     N kết quả đó. Trước đây nếu trước khi tìm kiếm người dùng đang xem 1
//     danh mục khác (VD: Handmade), bộ lọc danh mục cũ vẫn còn dính lại, nên
//     có thể làm kết quả hiện ra ít hơn hoặc bằng 0 dù dropdown báo có kết quả
//     — đây chính là lỗi "gõ tìm kiếm rồi kết quả bị mất" trong báo cáo.
// ============================================================================

let searchTimeout;
document.getElementById('gsearch').addEventListener('input', function(){
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(()=>doGSearch(),200);
});
document.getElementById('gsearch').addEventListener('keydown', function(e){
  if(e.key==='Escape') closeSearch();
  if(e.key==='Enter'){ e.preventDefault(); doGSearch(true); }
});

function doGSearch(fullSearch=false){
  const q = document.getElementById('gsearch').value.toLowerCase().trim();
  if(!q){ closeSearch(); return; }
  if(fullSearch){ globalSearchAll(q); return; } // Enter ⇒ đi thẳng tới trang kết quả đầy đủ
  const drop = document.getElementById('sdrop');
  const prods = PRODUCTS.filter(p=>p.n.toLowerCase().includes(q)||p.seller.toLowerCase().includes(q)||p.cat.toLowerCase().includes(q)).slice(0,4);
  const tuts = TUTORS.filter(t=>t.name.toLowerCase().includes(q)||t.subjects.some(s=>s.toLowerCase().includes(q))).slice(0,3);
  const fors = FORUM.filter(f=>f.title.toLowerCase().includes(q)||f.prev.toLowerCase().includes(q)).slice(0,2);
  const jbs = JOBS.filter(j=>j.title.toLowerCase().includes(q)||j.co.toLowerCase().includes(q)).slice(0,2);
  const total = prods.length+tuts.length+fors.length+jbs.length;
  if(!total){ drop.innerHTML=`<div class="sempty">🔍 Không tìm thấy kết quả cho "<strong>${q}</strong>"</div>`; drop.classList.remove('hide'); return; }
  let html='';
  if(prods.length){ html+=`<div class="sdiv"></div><div class="sg-title">🛍️ Sản phẩm</div>`+prods.map(p=>`<div class="si" onclick="openProductModal(${p.id});closeSearch()"><div class="si-ico">${p.e}</div><div class="si-main"><div class="si-name">${p.n}</div><div class="si-sub">Người bán: ${p.seller} · ${p.loc}</div></div><div class="si-price">${priceStr(p.p)}</div></div>`).join(''); }
  if(tuts.length){ html+=`<div class="sdiv"></div><div class="sg-title">📚 Gia sư</div>`+tuts.map(t=>`<div class="si" onclick="navigate('tutors');document.getElementById('tsearch').value='${t.name}';setTimeout(filterTutors,100);closeSearch()"><div class="si-ico" style="width:34px;height:34px;border-radius:50%;background:${t.color};display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:13px">${t.init}</div><div class="si-main"><div class="si-name">${t.name}</div><div class="si-sub">${t.subjects.slice(0,3).join(' · ')}</div></div><div class="si-price">${priceStr(t.price)}/giờ</div></div>`).join(''); }
  if(fors.length){ html+=`<div class="sdiv"></div><div class="sg-title">💬 Diễn đàn</div>`+fors.map(f=>`<div class="si" onclick="navigate('forum');closeSearch()"><div class="si-ico">💬</div><div class="si-main"><div class="si-name">${f.title}</div><div class="si-sub">${f.author} · ${f.time}</div></div></div>`).join(''); }
  if(jbs.length){ html+=`<div class="sdiv"></div><div class="sg-title">💼 Việc làm</div>`+jbs.map(j=>`<div class="si" onclick="navigate('jobs');closeSearch()"><div class="si-ico">${j.logo}</div><div class="si-main"><div class="si-name">${j.title}</div><div class="si-sub">${j.co}</div></div><div class="si-price">${j.pay}</div></div>`).join(''); }
  html+=`<div class="see-all-btn" onclick="globalSearchAll('${q}')">Xem tất cả ${total} kết quả cho "${q}"</div>`;
  drop.innerHTML=html; drop.classList.remove('hide');
}

function globalSearchAll(q){
  closeSearch();
  document.getElementById('gsearch').value=q;
  navigate('products',{pcat:'all'}); // luôn về "Tất cả" để không bị danh mục cũ che mất kết quả
  setTimeout(()=>{ document.getElementById('psearch').value=q; filterProducts(); },100);
}

function closeSearch(){ document.getElementById('sdrop').classList.add('hide'); }
document.addEventListener('click', e=>{ if(!e.target.closest('.sw')) closeSearch(); });
