// ============================================================================
// state.js — "Bộ nhớ" chung của toàn bộ web (trang hiện tại, giỏ hàng, các bộ
// lọc/tìm kiếm đang chọn...). Mọi file khác đọc/ghi vào object S này để biết
// và cập nhật trạng thái hiện tại của người dùng.
// ============================================================================

const S = {
  page: 'home',
  cart: [],
  wishlist: new Set(),
  pcat: 'all', pcond: 'all', psort: 'newest', psearch: '',
  tsubject: 'all', tprice: 0, tsort: 'rating', tsearch: '',
  fcat: 'all', fsearch: '',
  jtype: 'all', jsearch: '',
};
