// ============================================================================
// pages/tutors.js — Render trang "Tìm gia sư": danh sách môn học (pills),
// lọc theo môn/giá, sắp xếp, tìm kiếm theo tên hoặc môn dạy.
// ============================================================================

function renderTutors(){
  // Subject pills
  document.getElementById('subj-pills').innerHTML = TUTOR_SUBJECTS.map(s=>`
    <button class="pill${S.tsubject===s?' act':''}" onclick="setTSubj('${s}')">${s}</button>`).join('');
  filterTutors();
}

function filterTutors(){
  S.tsearch = (document.getElementById('tsearch')?.value||'').toLowerCase().trim();
  S.tprice = parseInt(document.getElementById('tprice')?.value||'0');
  S.tsort = document.getElementById('tsort')?.value||'rating';
  let list = [...TUTORS];
  if(S.tsearch) list=list.filter(t=>
    t.name.toLowerCase().includes(S.tsearch)||
    t.subjects.some(s=>s.toLowerCase().includes(S.tsearch))||
    t.faculty.toLowerCase().includes(S.tsearch)||
    t.bio.toLowerCase().includes(S.tsearch)
  );
  if(S.tsubject!=='Tất cả') list=list.filter(t=>t.subjects.some(s=>s.toLowerCase().includes(S.tsubject.toLowerCase())));
  if(S.tprice>0) list=list.filter(t=>t.price<=S.tprice);
  if(S.tsort==='rating') list.sort((a,b)=>b.rating-a.rating);
  else if(S.tsort==='price-asc') list.sort((a,b)=>a.price-b.price);
  else if(S.tsort==='price-desc') list.sort((a,b)=>b.price-a.price);
  else if(S.tsort==='reviews') list.sort((a,b)=>b.reviews-a.reviews);
  document.getElementById('tutor-count').textContent = `Tìm thấy ${list.length} gia sư`;
  const grid = document.getElementById('tutors-grid');
  if(!list.length){
    grid.innerHTML=`<div class="nores" style="grid-column:1/-1"><div class="nores-i">📚</div><p>Không tìm thấy gia sư phù hợp</p><p style="margin-top:8px"><a onclick="clearTutorFilter()" style="color:var(--blue3);cursor:pointer;font-weight:600">Xóa bộ lọc</a></p></div>`;
  } else {
    grid.innerHTML = list.map(t=>tutorCard(t)).join('');
  }
  document.querySelectorAll('#subj-pills .pill').forEach(pill=>pill.classList.toggle('act',pill.textContent===S.tsubject));
}

function setTSubj(s){ S.tsubject=s; filterTutors(); }
function clearTutorFilter(){ S.tsubject='Tất cả';S.tsearch='';S.tprice=0; document.getElementById('tsearch').value=''; document.getElementById('tprice').value='0'; renderTutors(); }
