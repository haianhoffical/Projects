// ============================================================================
// pages/jobs.js — Render trang "Việc làm": lọc theo loại việc, tìm theo từ khóa.
// ============================================================================

function renderJobs(){
  document.getElementById('job-pills').innerHTML = JOB_TYPES.map(t=>`
    <button class="pill${S.jtype===t?' act':''}" onclick="setJType('${t}')">${t}</button>`).join('');
  filterJobs();
}
function filterJobs(){
  S.jsearch = (document.getElementById('jsearch')?.value||'').toLowerCase();
  let list = [...JOBS];
  if(S.jtype!=='Tất cả') list=list.filter(j=>j.type===S.jtype);
  if(S.jsearch) list=list.filter(j=>j.title.toLowerCase().includes(S.jsearch)||j.co.toLowerCase().includes(S.jsearch));
  document.getElementById('jobs-list').innerHTML = list.length ? list.map(j=>jobCard(j)).join('') : `<div class="nores"><div class="nores-i">💼</div><p>Không tìm thấy việc làm phù hợp</p></div>`;
  document.querySelectorAll('#job-pills .pill').forEach(pill=>pill.classList.toggle('act',pill.textContent===S.jtype));
}
function setJType(t){ S.jtype=t; filterJobs(); }
