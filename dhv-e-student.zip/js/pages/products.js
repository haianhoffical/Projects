// ============================================================================
// pages/products.js — Render trang "Mua & Bán": danh sách danh mục (pills),
// lọc theo danh mục/tình trạng/giá, tìm kiếm, sắp xếp.
// ============================================================================

function renderProducts(){
  const catLabels = {all:'Tất cả',fashion:'👗 Thời trang',electronics:'📱 Điện tử',handmade:'🎨 Handmade',books:'📚 Sách vở',household:'🏠 Gia dụng',vehicles:'🚲 Xe & PT',entertainment:'🎮 Giải trí',cosmetics:'💄 Mỹ phẩm'};
  const allCats = ['all',...CATS.map(c=>c.id)];
  document.getElementById('cat-pills').innerHTML = allCats.map(c=>`
    <button class="pill${S.pcat===c?' act':''}" data-cat="${c}" onclick="setPCat('${c}')">${catLabels[c]}</button>`).join('');
  const titleMap = {all:'🛍️ Mua & Bán',fashion:'👗 Thời trang',electronics:'📱 Điện tử',handmade:'🎨 Handmade',books:'📚 Sách vở',household:'🏠 Gia dụng',vehicles:'🚲 Xe & PT',entertainment:'🎮 Giải trí',cosmetics:'💄 Mỹ phẩm'};
  document.getElementById('products-title').textContent = titleMap[S.pcat]||'🛍️ Mua & Bán';
  filterProducts();
}

function filterProducts(){
  S.psearch = (document.getElementById('psearch')?.value||'').toLowerCase();
  S.pcond = document.getElementById('pcond')?.value||'all';
  S.psort = document.getElementById('psort')?.value||'newest';
  let list = [...PRODUCTS];
  if(S.pcat!=='all') list=list.filter(p=>p.cat===S.pcat);
  if(S.pcond!=='all') list=list.filter(p=>p.cond===S.pcond);
  if(S.psearch) list=list.filter(p=>p.n.toLowerCase().includes(S.psearch)||p.seller.toLowerCase().includes(S.psearch));
  if(S.psort==='price-asc') list.sort((a,b)=>a.p-b.p);
  else if(S.psort==='price-desc') list.sort((a,b)=>b.p-a.p);
  else list.reverse();
  document.getElementById('product-count').textContent = `Tìm thấy ${list.length} sản phẩm`;
  const grid = document.getElementById('products-grid');
  if(!list.length){
    grid.innerHTML=`<div class="nores" style="grid-column:1/-1"><div class="nores-i">🔍</div><p>Không tìm thấy sản phẩm phù hợp</p><p style="margin-top:8px"><a onclick="clearProductFilter()">Xóa bộ lọc</a></p></div>`;
  } else {
    grid.innerHTML = list.map(p=>productCard(p,true)).join('');
    // Restore wishlist state
    list.forEach(p=>{const btn=document.querySelector(`.wl[data-id="${p.id}"]`);if(btn&&S.wishlist.has(p.id))btn.classList.add('liked');});
  }
  // Update pills (so the highlighted pill always matches S.pcat, even when
  // filterProducts() runs on its own from typing in the search box)
  document.querySelectorAll('#cat-pills .pill').forEach(pill=>{
    pill.classList.toggle('act', pill.dataset.cat===S.pcat);
  });
}

function setPCat(cat){ S.pcat=cat; renderProducts(); }
function clearProductFilter(){ S.pcat='all';S.pcond='all';S.psearch=''; document.getElementById('pcond').value='all'; document.getElementById('psearch').value=''; renderProducts(); }
