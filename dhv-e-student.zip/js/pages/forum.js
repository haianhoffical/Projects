// ============================================================================
// pages/forum.js — Render trang "Diễn đàn": lọc theo chủ đề, tìm theo từ khóa.
// ============================================================================

function renderForum(){
  document.getElementById('forum-pills').innerHTML = FORUM_CATS.map(c=>`
    <button class="pill${S.fcat===c?' act':''}" onclick="setFCat('${c}')">${c}</button>`).join('');
  filterForum();
}
function filterForum(){
  S.fsearch = (document.getElementById('fsearch')?.value||'').toLowerCase();
  let list = [...FORUM];
  if(S.fcat!=='Tất cả') list=list.filter(f=>f.cat===S.fcat);
  if(S.fsearch) list=list.filter(f=>f.title.toLowerCase().includes(S.fsearch)||f.prev.toLowerCase().includes(S.fsearch));
  document.getElementById('forum-list').innerHTML = list.length ? list.map(f=>forumCard(f)).join('') : `<div class="nores"><div class="nores-i">💬</div><p>Không tìm thấy bài viết phù hợp</p></div>`;
  document.querySelectorAll('#forum-pills .pill').forEach(pill=>pill.classList.toggle('act',pill.textContent===S.fcat));
}
function setFCat(c){ S.fcat=c; filterForum(); }
