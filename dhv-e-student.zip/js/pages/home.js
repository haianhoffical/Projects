// ============================================================================
// pages/home.js — Render trang chủ: lưới danh mục, sản phẩm secondhand nổi
// bật, gia sư nổi bật.
// ============================================================================

function renderHome(){
  // Categories
  document.getElementById('home-cats').innerHTML = CATS.map(c=>`
    <div class="cat ${c.bg}" onclick="navigate('products',{pcat:'${c.id}'})">
      <div class="ce">${c.e}</div><div class="cn">${c.n}</div><div class="cc">${c.c}</div>
    </div>`).join('');
  // Products (secondhand/used only, first 5)
  const p5 = PRODUCTS.filter(p=>p.cond!=='new').slice(0,5);
  document.getElementById('home-products').innerHTML = p5.map(p=>productCard(p,false)).join('');
  // Tutors (first 4)
  document.getElementById('home-tutors').innerHTML = TUTORS.slice(0,4).map(t=>tutorCard(t)).join('');
}
