// ============================================================================
// wishlist.js — Bật/tắt "yêu thích" (♥) cho một sản phẩm.
// ============================================================================
function toggleWishlist(id, btn){
  if(S.wishlist.has(id)){ S.wishlist.delete(id); btn.classList.remove('liked'); showToast('Đã bỏ khỏi yêu thích'); }
  else { S.wishlist.add(id); btn.classList.add('liked'); showToast('Đã thêm vào yêu thích ♥'); }
}
